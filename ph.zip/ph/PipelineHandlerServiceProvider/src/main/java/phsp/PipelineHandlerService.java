package phsp;

import phsp.spi.PipelineHandler;

import java.io.Serializable;

import java.util.Iterator;
import java.util.ServiceConfigurationError;
import java.util.ServiceLoader;

public class PipelineHandlerService implements Serializable {
	private static PipelineHandlerService service;

	private ServiceLoader<PipelineHandler> loader;

	private PipelineHandlerService() {
		loader = ServiceLoader.load(PipelineHandler.class);
	}

	public static synchronized PipelineHandlerService getInstance() {
		if(service == null) {
			service = new PipelineHandlerService();
		}
		return service;
	}

	public PipelineHandler getPipelineHandler(String pipelineHandlerClassName) throws ServiceConfigurationError {
		Iterator<PipelineHandler> handlers = loader.iterator();
		while(handlers.hasNext()) {
			PipelineHandler handler = handlers.next();
			if(handler.getClass().getName().equals(pipelineHandlerClassName))
				return handler;
		}
	        
		throw new IllegalArgumentException(pipelineHandlerClassName);
	}

	public void registerPipelineHandlers(PipelineHandlerRegister pipelineHandlerRegister) 
		throws ServiceConfigurationError {
		Iterator<PipelineHandler> handlers = loader.iterator();
		while(handlers.hasNext()) {
			PipelineHandler handler = handlers.next();
			pipelineHandlerRegister.register(handler.getClass().getName(), handler.getDescription());
		}
	}

	public interface PipelineHandlerRegister extends Serializable {
		void register(String className,String description);
	}
}
