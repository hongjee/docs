package phsp.spi;

public class PipelineHandlerException extends Exception {
	public PipelineHandlerException(String message) {
		super(message);
	}
}

