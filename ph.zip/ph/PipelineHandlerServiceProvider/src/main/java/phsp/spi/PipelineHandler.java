package phsp.spi;

import java.io.Serializable;

import java.util.Properties;
import java.util.Map;

public interface PipelineHandler extends Serializable {

	String getDescription();
	
	void handlePipeline(Map<String, Properties> pipelineConfig) throws PipelineHandlerException;

}

