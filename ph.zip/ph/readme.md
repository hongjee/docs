cd ph

cd PipelineHandlerServiceProvider
mvn install
cd ..

cd CommonPipelineHandlers
mvn clean compile package
cd ..

cd PipelineRunner
mvn clean compile assembly:single
cd ..

cd sqlite
mvn clean compile assembly:single
cd ..
java -jar sqlite/target/sqlitedb-1.0-jar-with-dependencies.jar
java -jar sqlite/target/sqlitedb-1.0-jar-with-dependencies.jar dumppipeline.conf
java -jar sqlite/target/sqlitedb-1.0-jar-with-dependencies.jar show
java -jar sqlite/target/sqlitedb-1.0-jar-with-dependencies.jar demo dumppipeline

java -cp CommonPipelineHandlers/target/common.pipelinehandlers-1.0.jar:PipelineRunner/target/pipeline.runner-1.0-jar-with-dependencies.jar:PipelineHandlerServiceProvider/target/pipelinehandler.serviceprovider-1.0.jar app.PipelineRunner demo dumppipeline 20200410 dev

java -jar sqlite/target/sqlitedb-1.0-jar-with-dependencies.jar dumppipeline2.conf
java -jar sqlite/target/sqlitedb-1.0-jar-with-dependencies.jar demo dumppipeline2

java -cp CommonPipelineHandlers/target/common.pipelinehandlers-1.0.jar:PipelineRunner/target/pipeline.runner-1.0-jar-with-dependencies.jar:PipelineHandlerServiceProvider/target/pipelinehandler.serviceprovider-1.0.jar app.PipelineRunner demo dumppipeline2 20200410 dev

java -jar sqlite/target/sqlitedb-1.0-jar-with-dependencies.jar demopipeline.conf
java -jar sqlite/target/sqlitedb-1.0-jar-with-dependencies.jar demo demopipeline

java -cp CommonPipelineHandlers/target/common.pipelinehandlers-1.0.jar:PipelineRunner/target/pipeline.runner-1.0-jar-with-dependencies.jar:PipelineHandlerServiceProvider/target/pipelinehandler.serviceprovider-1.0.jar app.PipelineRunner demo demopipeline 20200410 dev

java -jar sqlite/target/sqlitedb-1.0-jar-with-dependencies.jar hivepipeline.conf
java -jar sqlite/target/sqlitedb-1.0-jar-with-dependencies.jar movedata hive2cassandra

java -cp CommonPipelineHandlers/target/common.pipelinehandlers-1.0.jar:PipelineRunner/target/pipeline.runner-1.0-jar-with-dependencies.jar:PipelineHandlerServiceProvider/target/pipelinehandler.serviceprovider-1.0.jar:Hive2CassandraPipelineHandler/target/hive2cassandra.pipelinehandlers-1.0.jar:Hive2CassandraPipelineHandler/target/hive2cassandra.pipelinehandlers-1.0.jar app.PipelineRunner movedata hive2cassandra 20200410 dev





