package app;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.StringReader;
import java.io.IOException;
import java.util.stream.Collectors;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class SqliteClient {
    // dbfile: full path of the db file, for example, c:/d1/db/test.db, or /d1/db/test.db
    static void createTable(String dbfile) {
        String url = String.format("jdbc:sqlite:%s", dbfile);
	String sql = String.join(System.lineSeparator(),
			"CREATE TABLE IF NOT EXISTS config (",
		        "	system text NOT NULL,",
		        "	pipelineName text NOT NULL,",
			"	pipelineHandler text NOT NULL,",
			"	config text NOT NULL,",
			" PRIMARY KEY(system, pipelineName)",
		        ");");

        try (Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement() ) {
            stmt.execute(sql);
	    System.out.println("table created");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    static String readFile(String file) throws IOException {
	BufferedReader reader = new BufferedReader(new FileReader(new File(file)));
	return reader.lines().collect(Collectors.joining(System.lineSeparator()));	
    }

    static void insertData(String dbfile, String configFile) {
        String url = String.format("jdbc:sqlite:%s", dbfile);
	String insert = String.join(System.getProperty("line.separator"),
			"INSERT INTO config (system,pipelineName,pipelineHandler,config)",
			" VALUES (?,?,?,?)");

        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement stmt = conn.prepareStatement(insert) ) {
	String content = readFile(configFile);
	//System.out.println(content);
	Config conf = ConfigFactory.parseReader(new StringReader(content));
	//Config conf = ConfigFactory.load();
	String system = conf.getString("pipeline.system");
	String name = conf.getString("pipeline.name");
	String handler = conf.getString("pipeline.handler");

            stmt.setString(1,system);
            stmt.setString(2,name);
            stmt.setString(3,handler);
            stmt.setString(4,content);
            stmt.executeUpdate();
	    System.out.println("data inserted");
        } catch (SQLException | IOException e) {
            System.out.println(e.getMessage());
        }
   }

    static void display(String dbfile) {
        String url = String.format("jdbc:sqlite:%s", dbfile);
	String sql = "SELECT system,pipelineName,pipelineHandler, config FROM config";

        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt  = conn.createStatement();
             ResultSet rs    = stmt.executeQuery(sql)){
           
            while (rs.next()) {
                System.out.println(String.format("%s\t%s\t%s\t%s", rs.getString("system"),
                                   rs.getString("pipelineName"),
                                   rs.getString("pipelineHandler"),
                                   rs.getString("config")));
            }
	    System.out.println("data displayed");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
   }

    static void display(String dbfile, String system, String name) {
        String url = String.format("jdbc:sqlite:%s", dbfile);
	String sql = "SELECT system,pipelineName,pipelineHandler, config FROM config WHERE system=? and pipelineName=?";

        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement stmt = conn.prepareStatement(sql) ){
            stmt.setString(1,system);
            stmt.setString(2,name);
             ResultSet rs    = stmt.executeQuery();
            while (rs.next()) {
                System.out.println(String.format("%s\t%s\t%s\t%s", rs.getString("system"),
                                   rs.getString("pipelineName"),
                                   rs.getString("pipelineHandler"),
                                   rs.getString("config")));
            }
	    System.out.println("data displayed");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
   }


    public static void main(String[] args) {
	if(args.length<1)  {
        	createTable("test.db");
		System.exit(0);
	}
	if(args.length==1)  {
		if(args[0].equals("show"))
			display("test.db");
		else 
			insertData("test.db", args[0]);

		System.exit(0);
	}

	display("test.db", args[0], args[1]);
	
    }
}

