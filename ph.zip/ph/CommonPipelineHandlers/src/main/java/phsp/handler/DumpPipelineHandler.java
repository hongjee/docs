package phsp.handler;

import phsp.spi.PipelineHandler;

import java.io.Serializable;
import java.util.Properties;
import java.util.Map;
import java.util.HashMap;

public class DumpPipelineHandler implements PipelineHandler, Serializable {
	public String getDescription() {
		return "dumps config info, useful to debug configurations";
	}

	public void handlePipeline(Map<String, Properties> pipelineConfig) {
		System.out.println(pipelineConfig);
	}
}
