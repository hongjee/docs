package phsp.handler;

import phsp.spi.PipelineHandler;

import java.io.Serializable;
import java.util.Properties;
import java.util.Map;
import java.util.HashMap;

public class DemoPipelineHandler implements PipelineHandler, Serializable {
	public String getDescription() {
		return "demo pipeline handler impl";
	}

	public void handlePipeline(Map<String, Properties> pipelineConfig) {
		System.out.println("handled by DemoPipelineHandler");
		System.out.println(pipelineConfig);
	}
}
