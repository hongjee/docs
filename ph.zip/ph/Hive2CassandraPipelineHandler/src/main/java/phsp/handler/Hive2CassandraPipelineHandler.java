package phsp.handler;

import phsp.spi.PipelineHandler;

import java.io.Serializable;
import java.util.Properties;
import java.util.Map;
import java.util.HashMap;

public class Hive2CassandraPipelineHandler implements PipelineHandler, Serializable {
	public String getDescription() {
		return "Hive2Cassandra pipeline handler: move data from hive tables to cassandra db";
	}

	public void handlePipeline(Map<String, Properties> pipelineConfig) {
		System.out.println("data moved from hive tables to cassandra db");
	}
}
