package app;

import phsp.PipelineHandlerService;
import phsp.spi.PipelineHandler;

import java.io.Serializable;
import java.util.Properties;
import java.util.Map;
import java.util.HashMap;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

import java.io.StringReader;
import java.io.IOException;



public class PipelineRunner implements Serializable {
	public static void main(String args[]) throws Exception {
		if(args.length<4) {
			Usage();
			System.exit(-1);
		}

		// register all available pipeline handlers for UI to consume
		PipelineHandlerService.getInstance().registerPipelineHandlers( (className, description) -> System.out.println(String.format("class %s registered: %s", className, description)));

		// prepare pipeline handler setting
		String systemName = args[0];
		String pipelineName = args[1];
		String asOfDate = args[2];
		String environment = args[3];
		
		Map<String, Properties> pipelineConfig = fetchPipelineConfig(systemName, pipelineName);

		// get pipeline handler through pipeline handler service
		String pipelineHandlerClassName = pipelineConfig.get("pipeline.meta")
				.getProperty("pipeline.handlerClassName");
		PipelineHandler handler = PipelineHandlerService.getInstance()
			.getPipelineHandler(pipelineHandlerClassName);

		// handle the pipeline
		handler.handlePipeline(pipelineConfig);

		// job done
		System.out.println(String.format("Pipeline %s.%s has been processed by the handler %s in %s as of %s",
			 systemName, pipelineName, handler.getClass().getName(), environment, asOfDate));
	}



	private static Map<String, Properties> fetchPipelineConfig(String systemName, String pipelineName) {
		String dbfile = "test.db";
		String url = String.format("jdbc:sqlite:%s", dbfile);
		String sql = "SELECT system,pipelineName,pipelineHandler, config FROM config WHERE system=? and pipelineName=?";

		try (Connection conn = DriverManager.getConnection(url);
		     PreparedStatement stmt = conn.prepareStatement(sql) ){
		    stmt.setString(1,systemName);
		    stmt.setString(2, pipelineName);
		     ResultSet rs    = stmt.executeQuery();
		    if (rs.next()) {
			return new HashMap<String, Properties>() {{
				Properties p = new Properties();
				p.setProperty("pipeline.system", systemName);
				p.setProperty("pipeline.name", pipelineName);
				p.setProperty("pipeline.handlerClassName", rs.getString("pipelineHandler"));
				p.setProperty("pipeline.config", rs.getString("config"));
				put("pipeline.meta", p);
			}};
		    }

                    throw new IllegalArgumentException(String.format("pipeline %s.%s not configured", systemName, pipelineName));

		} catch (SQLException e) {
		    System.out.println(e.getMessage());
		    throw new RuntimeException("sql exception", e);
		}	
		
	}

	private static void Usage() {
		// ...
		System.out.println(" ........");
		// ...
	}
}
