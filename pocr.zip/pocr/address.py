import requests 
  
URL = "https://us-street.api.smartystreets.com/street-address"

curl -v "https://us-zipcode.api.smartystreets.com/lookup?auth-id=696358380912952&city=mountain+view&state=CA&zipcode=94035" --referer https://test

street="123 main Schenectady NY"
authid="7ead86d7-c5fe-51d1-71dc-da01f44694ef"
authtoken="KKLBHGvwscV3ZR7mioID"
  
# defining a params dict for the parameters to be sent to the API 
PARAMS = {'street':street, 'auth-id':authid, 'auth-token':authtoken} 
  
# sending get request and saving the response as response object 
r = requests.get(url = URL, params = PARAMS) 
  
# extracting data in json format 
data = r.json() 
print(data)
  
  
# extracting latitude, longitude and formatted address  
# of the first matching location 
#latitude = data['results'][0]['geometry']['location']['lat'] 
#longitude = data['results'][0]['geometry']['location']['lng'] 
#formatted_address = data['results'][0]['formatted_address'] 
  
# printing the output 
#print("Latitude:%s\nLongitude:%s\nFormatted Address:%s"
#    %(latitude, longitude,formatted_address)) 