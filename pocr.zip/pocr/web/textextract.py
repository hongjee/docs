# coding:utf8
import sys
import cv2
import string
import re
from smartystreets_python_sdk import StaticCredentials, exceptions, ClientBuilder
from smartystreets_python_sdk.us_extract import Lookup
import textutil
import textdetect

def set2array(aSet):
	alist = []
	for item in aSet:
		alist.append(item)
	return alist;
		
def extractAccounts(text):
	# identify account #
	#print('Accounts: \r\n**********************\r\n')
  
	acctPatterns = [r"(\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+)",
            r"(\d*[xX]+\d+)",
            r"(\d+[xX]+\d*)"
        ]  
	accounts = set()
	for acctPattern in acctPatterns:
		accts = re.findall(acctPattern, text)
		if len(accts) > 0:
			accounts |= set(accts)
  
	return textutil.filterPhones(set2array(accounts))

def printAccounts(accounts):
	print('Found {} accounts.'.format(len(accounts)))
	for account in accounts:
		print('{}\n'.format(account))

	print()
	
def foundInAddress(account, addresses):
	for address in addresses:
		if account in address["text"]:
		    return True
		
		if len(address["candidates"]) > 0:
			for candidate in address["candidates"]:
				if account in candidate["delivery_line_1"]:
				    return True
				
				if account in candidate["last_line"]:
				    return True
	return False;	
	
def filterPostalCodesFromAccounts(accounts, addresses):
	alist = []
	for account in accounts:
		if not foundInAddress(account, addresses):
		    alist.append(account)

	return alist
	
def address2array(addresses):
	alist = []
	for address in addresses:
		addressDict = {"text":address.text, "verified": address.verified }
		candidateList = []
		if len(address.candidates) > 0:
			for candidate in address.candidates:
				candidateList.append( {
				"delivery_line_1": candidate.delivery_line_1, 
				"last_line": candidate.last_line,
				"rdi": candidate.metadata.rdi
				})
		addressDict.update({"candidates": candidateList})			
		alist.append(addressDict)
	return alist;

def dumpaddress(addresses):
	print('Addresses: \r\n**********************\r\n')
	for address in addresses:
		print('"{}"\n'.format(address.text))
		print('Verified? {}'.format(address.verified))
		if len(address.candidates) > 0:
			print('\nMatches:')
			for candidate in address.candidates:
				print(candidate.delivery_line_1)
				print(candidate.last_line)
				print(candidate.metadata.rdi)
				print()
		else:
			print()
			print('**********************\n')
	return;	
	
def extractAddresses(text):
	#apiURL = "https://us-extract.api.smartystreets.com/?auth-id=7ead86d7-c5fe-51d1-71dc-da01f44694ef&auth-token=KKLBHGvwscV3ZR7mioID"
	#apiURL = "https://us-extract.api.smartystreets.com/"
  
	auth_id="7ead86d7-c5fe-51d1-71dc-da01f44694ef"
	auth_token="KKLBHGvwscV3ZR7mioID"
	credentials = StaticCredentials(auth_id, auth_token)

	client = ClientBuilder(credentials).build_us_extract_api_client()
		
	lookup = Lookup(text)
	result = client.send(lookup)
	metadata = result.metadata
	print('Found {} addresses.'.format(metadata.address_count))
	print('{} of them were valid.'.format(metadata.verified_count))
	print()
	addresses = result.addresses
	#dumpaddress(addresses)
	return address2array(addresses)

def test(img):
	text = textdetect.img2text(img)
	print(text)
	print('Accounts: \r\n**********************\r\n')
	accounts = extractAccounts(text)
	printAccounts(accounts)
	
	addresses = extractAddresses(text)
	print(addresses)
	
	accounts = filterPostalCodesFromAccounts(accounts, addresses)
	print('Accounts after filter Postal codes: \r\n**********************\r\n')
	print(accounts)

if __name__ == '__main__':
    # read file
	imgPath = sys.argv[1]
	img = cv2.imread(imgPath)
	test(img)
	
	
	

