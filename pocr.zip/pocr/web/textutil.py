import re

def matchPhone(phone):
	phonePatterns = ["\d{3}-\d{3}-\w{4}", "\1-\d{3}-\d{3}-\w{4}",
            "\(\d{3}\)\d{3}-\w{4}", "\1-\(\d{3}\)\d{3}-\w{4}"
        ]  
	for p in phonePatterns:
	    if re.search(p, phone):
		    return True

	return False

def filterPhones(accounts):
	phones = []
	for account in accounts:
		if matchPhone(account):
			phones.append(account)
  
	return [x for x in accounts if x not in phones]
    
if __name__ == '__main__':
	accounts = [
		"800-780-2884",
		"1-800-752-6633",
		"1-212-243-1900",
		"1-800-752-6833",
		"1-888-825-5016",
		"23344-444444-899998",
		"23344-44-8999-98"
		]
	print("before filter")
	for account in accounts:
	    print(account)
	
	accounts = filterPhones(accounts)
	print("after filter")
	for account in accounts:
	    print(account)
	
	
	

