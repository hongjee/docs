# coding:utf8
import sys
import cv2
import numpy as np
import pytesseract
import string

### preprocess with Morphology
### this is very important to text region detect
### parameters
###    expandsion size: here use 30 x 9, can tune
###    errosion size: here use 24 x 6, can tune	
def preprocess(gray):
    # 1. Sobel operator: caculate gradient in x dimension
	sobel = cv2.Sobel(gray, cv2.CV_8U, 1, 0, ksize=3)
	
	# binarize
	ret, binary = cv2.threshold(sobel, 0, 255, cv2.THRESH_OTSU + cv2.THRESH_BINARY)
	
	# core functions to Expansion and corrosion 
	element1 = cv2.getStructuringElement(cv2.MORPH_RECT, (90, 27))
	element2 = cv2.getStructuringElement(cv2.MORPH_RECT, (72, 18))
	
	# Expand once to standout contour
	dilation = cv2.dilate(binary, element2, iterations = 1)
	
	# Erode once, remove details such as table lines etc. note here removes vertical lines
	erosion = cv2.erode(dilation, element1, iterations=1)
	
	# expand again, standout contour more
	dilation2 = cv2.dilate(erosion, element2, iterations = 2)
	
	# save images
	#cv2.imwrite('binary.png', binary)
	#cv2.imwrite('dilation.png', dilation)
	#cv2.imwrite('erosion.png', erosion)
	#cv2.imwrite('dilation2.png', dilation2)
	return dilation2
	
def findTextRegion(img):
	region = []
    
    # 1. look for contours
	contours, hierarchy = cv2.findContours(img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    
	# 2. filter those with smaller area
	for i in range(len(contours)):
		cnt = contours[i] 
		# caculate the area of the contour
		area = cv2.contourArea(cnt)
		
		# ignore those contours with smaller area
		if(area < 9000):
		    continue
			
		# find the mininmum rectangle which could have direction
		rect = cv2.minAreaRect(cnt)
		
		# box is a coordinate of 4 points
		box = cv2.boxPoints(rect)
		box = np.int0(box)
		# add the box into the region
		region.append(box)
		
	return region

### box: a bounding box in the form of 4 points [[x1, y1], [x1, y2], [x2, y2], [x2, y2]]
### return a bounding box in the form of (startX, startY, endX, endY) 
def box2rect(box):
   x1 = min(box[0][0], box[1][0], box[2][0], box[3][0])
   x2 = max(box[0][0], box[1][0], box[2][0], box[3][0])
   y1 = min(box[0][1], box[1][1], box[2][1], box[3][1])
   y2 = max(box[0][1], box[1][1], box[2][1], box[3][1])	
   return (x1, y1, x2, y2)

### rect: a bounding box in the form of (startX, startY, endX, endY) 
### return a bounding box in the form of 4 points [[x1, y1], [x1, y2], [x2, y2], [x2, y2]]
def rect2box(rect):
   boxes = []
   boxes.append([ [rect[0], rect[3]],[rect[0], rect[1]], [rect[2], rect[1]], [rect[2], rect[3]] ]);   
   boxes = np.int0(boxes)
   return boxes

# draw contours with green lines
def drawContours(img, boxes): 
	for box in boxes:
		cv2.drawContours(img, [box], 0, (0, 255, 0), 2)
	
    # save the picture with contours	
	cv2.imwrite('img-contours.png', img)
   
def detect(img):
    # 1. convert to gray image
	gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
	
	# 2. Preprocessing of morphological transformation to get a picture that can find rectangles
	dilation = preprocess(gray)
	
	# 3. find and filter text region
	boxes = findTextRegion(dilation)
	
	# 4. draw contours
	#drawContours(img, boxes)
	
	return boxes

def ocr(img, boxes):
    # initialize the list of results
    results = []

	# Used to print recognized text
    printable = set(string.printable)

    # loop over the bounding boxes
    for box in boxes:
        # extract the block
        #print(box)
        (startX, startY, endX, endY) = box2rect(box)
		
        block = img[startY:endY, startX:endX]
		
		# Define config parameters.
        # '-l eng'  for using the English language
        # '--oem 1' for using LSTM OCR Engine
        config = ('-l eng --oem 1 --psm 3')
        text = pytesseract.image_to_string(block, config=config)
        # Print recognized text
        text = ''.join(filter(lambda x: x in printable, text))

        # add the bounding box coordinates and OCR'd text to the list of results
        results.append(((startX, startY, endX, endY), text))

    # sort the results bounding box coordinates from top to bottom
    results = sorted(results, key=lambda r:r[0][1])
    return results

def img2text(img):
	boxes = detect(img)
	results = ocr(img, boxes)
	s = ''	
	for r in results:
		s = '{}\n{}'.format(s, r[1])
	
	return s
    
def text_from_image_file(imageFile):
	# Read image from disk
	img = cv2.imread(imageFile, cv2.IMREAD_COLOR)
	return img2text(img)

if __name__ == '__main__':
    # read image file and convert to text
	imgPath = sys.argv[1]
	print(text_from_image_file(imgPath))
	

