from wand.image import Image
import numpy as np
import io
import sys
import cv2

import textdetect
 
def pdf2jpeg_array(pdfFile, max_page=1, resolution=300):
	req_image = []
	image_pdf = Image(filename=pdfFile, resolution=resolution)
	image_jpeg = image_pdf.convert('jpeg')
	page = 1
	for img in image_jpeg.sequence:
		img_page = Image(image=img)
		req_image.append(img_page.make_blob('jpeg'))
		page += 1
		if page > max_page:
			return req_image
	return req_image

def ocr(pdfFile, max_page=1, resolution=300):
	jpegArray = pdf2jpeg_array(pdfFile, max_page, resolution)
	req_text = []
	for img in jpegArray: 
	    img_stream = io.BytesIO(img)
	    file_bytes = np.asarray(bytearray(img_stream.read()), dtype=np.uint8)
	    im = cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)	
	    text = textdetect.img2text(im)
	    req_text.append(text)
	return req_text

def pdf2text(pdfFile):
	texts = ocr(pdfFile, max_page = 2)
	s = ''	
	for r in texts:
		s = '{}\n{}'.format(s, r)
	return s
	
def pdf2jpegs(pdfFile, jpegFile):
	image_pdf = Image(filename=pdfFile, resolution=300)
	image_jpeg = image_pdf.convert('jpeg')
	image_jpeg.save(filename=jpegFile)
	
if __name__ == '__main__':
    # read file
	pdfFile = sys.argv[1]
	#jpegFile = sys.argv[2]
	#pdf2jpegs(pdfFile, jpegFile)
	print(pdf2text(pdfFile))
	
	
