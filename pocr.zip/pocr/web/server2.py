 ### Serve sttic files like index.html, style.css, javascript code and images
### read incoming data from an HTML form
### file upload with maxfile-size
### bill address and account ocr and extraction
from http.server import BaseHTTPRequestHandler,HTTPServer
import time
from os import curdir, sep
import cgi
import cv2
import sys
import re
import json
import string
import pytesseract
from smartystreets_python_sdk import StaticCredentials, exceptions, ClientBuilder
from smartystreets_python_sdk.us_extract import Lookup

HOST_NAME = ""
PORT_NUMBER = 8080

#This class will handles any incoming request from the browser 
class myHandler(BaseHTTPRequestHandler):
    #Handler for the GET requests
    def do_GET(self):
        if self.path=="/":
            self.path="/index.html"

        try:
            # Check the file extension required and set the right meme type
            sendReply = False
            if self.path.endswith(".html"):
                mimetype='text/html'
                sendReply = True
            if self.path.endswith(".jpg"):
                mimetype='image/jpg'
                sendReply = True
            if self.path.endswith(".gif"):
                mimetype='image/gif'
                sendReply = True
            if self.path.endswith(".js"):
                mimetype='application/javascript'
                sendReply = True
            if self.path.endswith(".css"):
                mimetype='text/css'
                sendReply = True
            if sendReply == True:
                #Open the static file requested and send it
                f = open(curdir + sep + self.path) 
                self.respond(f.read(), mimetype=mimetype)
                f.close()
            return
        except IOError:
            self.send_error(404,'File Not Found: %s' % self.path)


    #Handler for the POST requests
    def do_POST(self):
        if self.path=="/send":
            form = cgi.FieldStorage(
                fp=self.rfile, 
                headers=self.headers,
                environ={'REQUEST_METHOD':'POST','CONTENT_TYPE':self.headers['Content-Type'],
            })

            print("Your name is: %s" % form["your_name"].value)
            self.respond("Thanks %s !" % form["your_name"].value)
            return	
        if self.path=="/upload":
            length = int(self.headers['content-length'])
            print(length)
            # limit the max file size to 10 mb
            if length > 10000000:
                print("file to big")
				# have to read all request data in any case. 
				# otherwise HTTP client (browser) just don't get it.
                # when file is too big, just read and ignore data.
                read = 0
                while read < length:
                    read += len(self.rfile.read(min(66556, length - read)))
                
                # tell the user that file to big
                self.respond("file to big")
                return				
            else:
                form = cgi.FieldStorage(
                    fp=self.rfile, 
                    headers=self.headers,
                    environ={'REQUEST_METHOD':'POST','CONTENT_TYPE':self.headers['Content-Type'],
                })

                filename = form['file'].filename
                data = form['file'].file.read()
                open("upload/%s" % filename, "wb").write(data)
                print(length)
                result = self.ocr("upload/%s" % filename)
                #self.respond("Uploaded %s !" % filename)
                self.respond(json.dumps(result), mimetype='application/json')
                return	
    def respond(self, response, status=200, mimetype='text/html'):
        responseEncoded = bytes(response, "utf-8")
        self.send_response(status)
        self.send_header('Content-type',mimetype)
        self.send_header('Content-length',len(responseEncoded))
        self.end_headers()
        self.wfile.write(responseEncoded)
        return	
    def ocr(self, imPath):
        processResult = {}
		
		# Define config parameters.
        # '-l eng'  for using the English language
        # '--oem 1' for using LSTM OCR Engine
        config = ('-l eng --oem 1 --psm 3')

        # Read image from disk
        im = cv2.imread(imPath, cv2.IMREAD_COLOR)

        # Run tesseract OCR on image
        text = pytesseract.image_to_string(im, config=config)

        # Print recognized text
        #print(text)
        printable = set(string.printable)
        text = ''.join(filter(lambda x: x in printable, text))
  
        # identify account #
        print('Accounts: \r\n**********************\r\n')
  
        acctPatterns = [r"(\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+)",
            r"(\d*[xX]+\d+)",
            r"(\d+[xX]+\d*)"
        ]  
        accounts = set()
        for acctPattern in acctPatterns:
            accts = re.findall(acctPattern, text)
            if len(accts) > 0:
                accounts |= set(accts)
  
        #accounts = re.findall(r"(\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+)", text)
        processResult.update({"accounts": self.set2array(accounts)})
        print('Found {} accounts.'.format(len(accounts)))
        for account in accounts:
            print('{}\n'.format(account))

        print()
  
        #apiURL = "https://us-extract.api.smartystreets.com/?auth-id=7ead86d7-c5fe-51d1-71dc-da01f44694ef&auth-token=KKLBHGvwscV3ZR7mioID"
        apiURL = "https://us-extract.api.smartystreets.com/"
  
        auth_id="7ead86d7-c5fe-51d1-71dc-da01f44694ef"
        auth_token="KKLBHGvwscV3ZR7mioID"
        credentials = StaticCredentials(auth_id, auth_token)

        client = ClientBuilder(credentials).build_us_extract_api_client()
		
        lookup = Lookup(text)
        result = client.send(lookup)
        metadata = result.metadata
        print('Found {} addresses.'.format(metadata.address_count))
        print('{} of them were valid.'.format(metadata.verified_count))
        print()
        addresses = result.addresses
        processResult.update({"addresses": self.address2array(addresses)})

        print('processResult: \r\n**********************\r\n')
        print(json.dumps(processResult))
        return	processResult
    def set2array(self, aSet):
        alist = []
        for item in aSet:
            alist.append(item)
        return alist;
    def address2array(self, addresses):
        alist = []
        for address in addresses:
            addressDict = {"text":address.text, "verified": address.verified }
            candidateList = []
            if len(address.candidates) > 0:
                for candidate in address.candidates:
                    candidateList.append( {"delivery_line_1": candidate.delivery_line_1, "last_line": candidate.last_line})
            addressDict.update({"candidates": candidateList})			
            alist.append(addressDict)
        return alist;
    def dumpaddress(self, addresses):
        print('Addresses: \r\n**********************\r\n')
        for address in addresses:
            print('"{}"\n'.format(address.text))
            print('Verified? {}'.format(address.verified))
            if len(address.candidates) > 0:
                print('\nMatches:')
                for candidate in address.candidates:
                    print(candidate.delivery_line_1)
                    print(candidate.last_line)
                    print()
            else:
                print()
                print('**********************\n')
        return;
	
#Create a web server and define the handler to manage the incoming request
server = HTTPServer((HOST_NAME, PORT_NUMBER), myHandler)
print('{}: Server Started - ({}, {}).'.format(time.asctime(), HOST_NAME, PORT_NUMBER))
try:
    #Wait forever for incoming http requests
    server.serve_forever()
except KeyboardInterrupt:
    print('^C received, shutting down the web server')
    pass

server.server_close()
print('{}: Server Stopped - ({}, {}).'.format(time.asctime(), HOST_NAME, PORT_NUMBER))
