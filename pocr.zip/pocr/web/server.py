 ### Serve sttic files like index.html, style.css, javascript code and images
### read incoming data from an HTML form
### file upload with maxfile-size
### bill address and account ocr and extraction
from http.server import BaseHTTPRequestHandler,HTTPServer
import time
from os import curdir, sep
import cgi
import sys
import json

import textdetect
import textextract
import ocrpdf

HOST_NAME = ""
PORT_NUMBER = 8080

#This class will handles any incoming request from the browser 
class myHandler(BaseHTTPRequestHandler):
    #Handler for the GET requests
    def do_GET(self):
        if self.path=="/":
            self.path="/index.html"

        try:
            # Check the file extension required and set the right meme type
            sendReply = False
            if self.path.endswith(".html"):
                mimetype='text/html'
                sendReply = True
            if self.path.endswith(".jpg"):
                mimetype='image/jpg'
                sendReply = True
            if self.path.endswith(".gif"):
                mimetype='image/gif'
                sendReply = True
            if self.path.endswith(".js"):
                mimetype='application/javascript'
                sendReply = True
            if self.path.endswith(".css"):
                mimetype='text/css'
                sendReply = True
            if sendReply == True:
                #Open the static file requested and send it
                f = open(curdir + sep + self.path) 
                self.respond(f.read(), mimetype=mimetype)
                f.close()
            return
        except IOError:
            self.send_error(404,'File Not Found: %s' % self.path)


    #Handler for the POST requests
    def do_POST(self):
        if self.path=="/send":
            form = cgi.FieldStorage(
                fp=self.rfile, 
                headers=self.headers,
                environ={'REQUEST_METHOD':'POST','CONTENT_TYPE':self.headers['Content-Type'],
            })

            print("Your name is: %s" % form["your_name"].value)
            self.respond("Thanks %s !" % form["your_name"].value)
            return	
        if self.path=="/upload":
            length = int(self.headers['content-length'])
            print("Incoming file size: %d" % length)
            # limit the max file size to 10 mb
            if length > 10000000:
                print("file is too big and will be ignored")
				# have to read all request data in any case. 
				# otherwise HTTP client (browser) just don't get it.
                # when file is too big, just read and ignore data.
                read = 0
                while read < length:
                    read += len(self.rfile.read(min(66556, length - read)))
                
                # tell the user that file to big
                self.respond("file to big")
                return				
            else:
                form = cgi.FieldStorage(
                    fp=self.rfile, 
                    headers=self.headers,
                    environ={'REQUEST_METHOD':'POST','CONTENT_TYPE':self.headers['Content-Type'],
                })

                filename = form['file'].filename
                data = form['file'].file.read()
                open("upload/%s" % filename, "wb").write(data)
                print("file is saved in upload/%s" % filename)
                print("starting to process the file in upload/%s" % filename)
                result = self.ocr("upload/%s" % filename)
                self.respond(json.dumps(result), mimetype='application/json')
                return	
    def respond(self, response, status=200, mimetype='text/html'):
        responseEncoded = bytes(response, "utf-8")
        self.send_response(status)
        self.send_header('Content-type',mimetype)
        self.send_header('Content-length',len(responseEncoded))
        self.end_headers()
        self.wfile.write(responseEncoded)
        return	
    def ocr(self, imPath):
        processResult = {}
		
        text = ''
        if imPath.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.tiff')):
            text = textdetect.text_from_image_file(imPath)
        elif imPath.lower().endswith('.pdf'):
            text = ocrpdf.pdf2text(imPath)
        else:
            return processResult

		# identify addresses #
        print('Addresses: \r\n**********************\r\n')
        addresses = textextract.extractAddresses(text)
        print(addresses)
        print()
        processResult.update({"addresses": addresses})

        # identify account #
        print('Accounts: \r\n**********************\r\n')
        accounts = textextract.extractAccounts(text)
        print(accounts)
        print()

        accounts = textextract.filterPostalCodesFromAccounts(accounts, addresses)
        print('Accounts after filter Postal codes: \r\n**********************\r\n')
        print(accounts)
        print()
        processResult.update({"accounts": accounts})

        print('processResult: \r\n**********************\r\n')
        print(json.dumps(processResult))
        return processResult
	
#Create a web server and define the handler to manage the incoming request
server = HTTPServer((HOST_NAME, PORT_NUMBER), myHandler)
print('{}: Server Started - ({}, {}).'.format(time.asctime(), HOST_NAME, PORT_NUMBER))
try:
    #Wait forever for incoming http requests
    server.serve_forever()
except KeyboardInterrupt:
    print('^C received, shutting down the web server')
    pass

server.server_close()
print('{}: Server Stopped - ({}, {}).'.format(time.asctime(), HOST_NAME, PORT_NUMBER))
