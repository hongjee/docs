Vue.component('vueapp-result', {
	props: ['result'],
	template: ' <div><h2>Account List</h2>\
				<ul>\
				    <li v-for="item in result.accounts"><span>{{ item }} </span></li>\
				</ul>\
				<h2>Address List</h2>	\
				<ul>\
				    <li v-for="address in result.addresses">\
						<span>{{ address.text }} </span><br/>\
						<span>Verified: {{ address.verified }}</span><br/>\
						<h3>Candidates</h3>\
						<ol>\
						  <li v-for="candidate in address.candidates">\
							<span>{{ candidate.delivery_line_1 }} </span><br/>\
							<span>{{ candidate.last_line }} </span><br/>\
							<span>{{ candidate.rdi }} </span>\
						  </li>\
						</ol>\
					</li>\
				</ul>\
				</div>\
	',
})