
var app = new Vue({
	  el: "#app",
	  data() {
		return {
		  intervalId:'',
		  file: '',
		  fileMessage: '',
		  image: '',
		  rotate: 0,
		  isZoomed: false,
		  result: '',
		  processing: ''
		}
	  },
	  computed: {
		 rotateStyle () {
			return { transform: 'rotate(' + this.rotate + 'turn)'}
		 },
		 isImages () {
			return this.isImage(this.file)
		 },
		 isPdfs () {
			return this.isPdf(this.file)
		 }
	  },	  
	  methods:{
		isImage(ff) {
			var f = ff.name;
			return f.endsWith('.png') || f.endsWith('.jpg') || f.endsWith('.jpeg') || f.endsWith('.tiff') || f.endsWith('.gif');
		},
		isPdf(ff) {
			var f = ff.name;
			return f.endsWith('.pdf');
		},
		toggleZoom() {
			this.isZoomed = !this.isZoomed;
			if(this.isZoomed) {
				w = this.$refs.myimg.clientWidth;
				h = this.$refs.myimg.clientHeight;
				this.$refs.myimg.style.width = (w * 2) + "px";
				this.$refs.myimg.style.height = (h * 2) + "px";
			} else {
				w = this.$refs.myimg.clientWidth;
				h = this.$refs.myimg.clientHeight;
				this.$refs.myimg.style.width = (w / 2) + "px";
				this.$refs.myimg.style.height = (h / 2) + "px";
			}
		},
		rotateLeft(){
			this.rotate -= 0.25;
        },
		rotateRight(){
			this.rotate += 0.25;
        },
		handleFileUpload(){
			// What we will do in this method is set a local variable to the value of the file uploaded. 
			// Now since we are using a modern browser, this will be a FileList object: 
			//	FileList Web APIs | MDN which contains File objects: 
			//	File Web APIs | MDN. 
			// The FileList is not directly editable by the user for security reasons. 
			// However, we can allow users to select and de-select files as needed
			console.log(this.$refs.file.files[0]);
			if(this.isPdf(this.$refs.file.files[0]) || this.isImage(this.$refs.file.files[0])) {
			   this.file = this.$refs.file.files[0];
			   this.createImage(this.file);
			   this.fileMessage = '';
			} else {
			   this.fileMessage = 'Invalid file format. Accept files are either images (.png, .jpg, .jpeg, .tiff, .gif) or PDFs (.pdf)';
			}
        },
		submitFile(){
			self = this;
			// Submit file to server through Axios
			let formData = new FormData();
			formData.append('file', this.file);
			self.processing = 'Please wait processing ...'
			self.intervalId = setInterval(function(){
				self.processing = self.processing + '..'
			}, 2 * 1000);
			
			axios.post( '/upload', formData, {
					headers: {
						'Content-Type': 'multipart/form-data'
					}
				  }
			).then(function(response){
				  console.log('SUCCESS!!');
				  self.result = response.data;
				  console.log(self.result);
				  clearInterval(self.intervalId);
				  self.processing = 'Succeeded!';
			})
			.catch(function(){
				  console.log('FAILURE!!');
				  clearInterval(self.intervalId);
				  self.processing = 'Failed!';
			});
		},		
		createImage(file) {
		  var image = new Image();
		  var reader = new FileReader();
		  var vm = this;

		  reader.onload = (e) => {
			vm.image = e.target.result;
		  };
		  reader.readAsDataURL(file);
		},
		removeImage: function (e) {
		  this.image = '';
		  this.result = '';
		  this.processing = '';
		}
	  }
});
	