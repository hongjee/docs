import cv2
import sys
import re
import pytesseract
import os
from smartystreets_python_sdk import StaticCredentials, exceptions, ClientBuilder
from smartystreets_python_sdk.us_extract import Lookup

if __name__ == '__main__':
  if len(sys.argv) < 2:
    print('Usage: python3 ocr.py image.jpg')
    sys.exit(1)

  # Read image path from command line
  imPath = sys.argv[1]

  # Uncomment the line below to provide path to tesseract manually
  # pytesseract.pytesseract.tesseract_cmd = '/usr/bin/tesseract'

  # Define config parameters.
  # '-l eng'  for using the English language
  # '--oem 1' for using LSTM OCR Engine
  config = ('-l eng --oem 1 --psm 3')

  # Read image from disk
  im = cv2.imread(imPath, cv2.IMREAD_COLOR)

  # Run tesseract OCR on image
  text = pytesseract.image_to_string(im, config=config)

  # Print recognized text
  #print(text)
  
  # identify account #
  print('Accounts: \r\n**********************\r\n')
  
  acctPatterns = [r"(\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+)",
        r"(\d*[xX]+\d+)",
        r"(\d+[xX]+\d*)"
       ]  
  accounts = set()
  for acctPattern in acctPatterns:
    accts = re.findall(acctPattern, text)
    if len(accts) > 0:
        accounts |= set(accts)
  
  #accounts = re.findall(r"(\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+\-?\d+)", text)
  print('Found {} accounts.'.format(len(accounts)))
  for account in accounts:
    print('{}\n'.format(account))

  print()
  
  #apiURL = "https://us-extract.api.smartystreets.com/?auth-id=7ead86d7-c5fe-51d1-71dc-da01f44694ef&auth-token=KKLBHGvwscV3ZR7mioID"
  apiURL = "https://us-extract.api.smartystreets.com/"
  
  auth_id="7ead86d7-c5fe-51d1-71dc-da01f44694ef"
  auth_token="KKLBHGvwscV3ZR7mioID"
  # We recommend storing your secret keys in environment variables instead---it's safer!
  # auth_id = os.environ['SMARTY_AUTH_ID']
  # auth_token = os.environ['SMARTY_AUTH_TOKEN']
  
  credentials = StaticCredentials(auth_id, auth_token)

  client = ClientBuilder(credentials).build_us_extract_api_client()
  lookup = Lookup(text)
  result = client.send(lookup)
  metadata = result.metadata
  print('Found {} addresses.'.format(metadata.address_count))
  print('{} of them were valid.'.format(metadata.verified_count))
  print()
  addresses = result.addresses
  
  print('Addresses: \r\n**********************\r\n')
  for address in addresses:
    print('"{}"\n'.format(address.text))
    print('Verified? {}'.format(address.verified))
    if len(address.candidates) > 0:
      print('\nMatches:')
      for candidate in address.candidates:
        print(candidate.delivery_line_1)
        print(candidate.last_line)
        print()
    else:
        print()
        print('**********************\n')
