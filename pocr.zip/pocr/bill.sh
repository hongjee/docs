tesseract bill.jpg bill -l eng --oem 1 --psm 3

ls