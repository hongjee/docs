# OpenCV OCR and text recognition with Tesseract
#
# import the necessary packages
from imutils.object_detection import non_max_suppression
import numpy as np
import pytesseract
import argparse
import cv2